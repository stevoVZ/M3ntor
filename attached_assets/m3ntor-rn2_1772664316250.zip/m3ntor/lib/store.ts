import { create } from 'zustand';
import type { Item, JourneyProgress, Profile } from '../types';
import { fetchItems, fetchJourneyProgress, upsertItem, deleteItem } from './supabase';

// ─────────────────────────────────────────────────────────
// App State — Zustand store
// Single source of truth for all screens
// ─────────────────────────────────────────────────────────

interface AppState {
  // Data
  items:     Item[];
  journeys:  JourneyProgress[];
  profile:   Profile | null;
  userId:    string | null;

  // UI
  loading:   boolean;
  error:     string | null;

  // Auth
  setUserId: (id: string | null) => void;
  setProfile:(p: Profile | null) => void;

  // Data actions
  loadAll:   (userId: string) => Promise<void>;
  addItem:   (item: Item) => void;
  updateItem:(id: string, patch: Partial<Item>) => void;
  removeItem:(id: string) => void;
  setItems:  (items: Item[]) => void;

  // Derived selectors
  activeItems:   () => Item[];
  pausedItems:   () => Item[];
  somedayItems:  () => Item[];
  projectItems:  () => Item[];
  habitItems:    () => Item[];
  actionItems:   () => Item[];
  itemsByArea:   (area: string) => Item[];
  todaySteps:    () => Array<{ item: Item; stepId: string }>;
}

export const useStore = create<AppState>((set, get) => ({
  items:    [],
  journeys: [],
  profile:  null,
  userId:   null,
  loading:  false,
  error:    null,

  setUserId:  (id)  => set({ userId: id }),
  setProfile: (p)   => set({ profile: p }),

  loadAll: async (userId) => {
    set({ loading: true, error: null });
    try {
      const [items, journeys] = await Promise.all([
        fetchItems(userId),
        fetchJourneyProgress(userId),
      ]);
      set({ items: items ?? [], journeys: journeys ?? [], loading: false });
    } catch (e) {
      set({ error: (e as Error).message, loading: false });
    }
  },

  addItem: (item) => {
    set(s => ({ items: [item, ...s.items] }));
    // Persist to Supabase in background
    upsertItem(item as unknown as Record<string, unknown>).catch(console.error);
  },

  updateItem: (id, patch) => {
    set(s => ({
      items: s.items.map(i => i.id === id ? { ...i, ...patch, updated_at: new Date().toISOString() } : i),
    }));
    const updated = get().items.find(i => i.id === id);
    if (updated) upsertItem(updated as unknown as Record<string, unknown>).catch(console.error);
  },

  removeItem: (id) => {
    set(s => ({ items: s.items.filter(i => i.id !== id) }));
    deleteItem(id).catch(console.error);
  },

  setItems: (items) => set({ items }),

  // ── Derived selectors ─────────────────────────────────
  activeItems:  () => get().items.filter(i => i.status === 'active'),
  pausedItems:  () => get().items.filter(i => i.status === 'paused'),
  somedayItems: () => get().items.filter(i => i.status === 'someday'),

  projectItems: () => get().items.filter(
    i => i.status === 'active' && (i.steps?.length ?? 0) > 0
  ),
  habitItems: () => get().items.filter(
    i => i.status === 'active' && !!i.recurrence
  ),
  actionItems: () => get().items.filter(
    i => i.status === 'active' && !i.steps?.length && !i.recurrence
  ),

  itemsByArea: (area) => get().items.filter(
    i => (i.status === 'active' || i.status === 'paused') &&
         (i.area === area || (i.secondary_areas ?? []).includes(area))
  ),

  todaySteps: () => {
    const result: Array<{ item: Item; stepId: string }> = [];
    for (const item of get().items) {
      if (item.status !== 'active' || !item.steps) continue;
      for (const step of item.steps) {
        if (step.today && !step.done) result.push({ item, stepId: step.id });
      }
    }
    return result;
  },
}));
