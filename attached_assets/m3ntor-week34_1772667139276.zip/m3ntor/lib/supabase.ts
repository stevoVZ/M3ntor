import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SUPABASE_URL  = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const SUPABASE_KEY  = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

if (!SUPABASE_URL || !SUPABASE_KEY) {
  throw new Error('Missing Supabase env vars. Check your .env file.');
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    storage:          AsyncStorage,
    autoRefreshToken: true,
    persistSession:   true,
    detectSessionInUrl: false,
  },
});

// ── Typed query helpers ───────────────────────────────────

export async function fetchItems(userId: string) {
  const { data, error } = await supabase
    .from('items')
    .select('*, steps(*, subtasks(*))')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

export async function upsertItem(item: Record<string, unknown>) {
  const { data, error } = await supabase
    .from('items')
    .upsert(item)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteItem(id: string) {
  const { error } = await supabase.from('items').delete().eq('id', id);
  if (error) throw error;
}

export async function upsertStep(step: Record<string, unknown>) {
  const { data, error } = await supabase
    .from('steps')
    .upsert(step)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function upsertSubtask(subtask: Record<string, unknown>) {
  const { data, error } = await supabase
    .from('subtasks')
    .upsert(subtask)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function fetchJourneyProgress(userId: string) {
  const { data, error } = await supabase
    .from('journey_progress')
    .select('*')
    .eq('user_id', userId);
  if (error) throw error;
  return data;
}
